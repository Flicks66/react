import './App.css';
import Article from './components/Article';

function App() {
  return (
    <div className="App">
      {/* <Articles /> */}
      <Article title="Artikle 1" author="Daniel" text="Lorem ipsum dolor sit amet consectetur adipiscing elit. Consectetur aut ea reprehenderit unde quisquam doloremque ducimus assumenda magnam praesentium, similique asperiores corrupti maiores, quis minima molestias eum id cum iusto."
  />
      <Article title="Artikle 2" text="Lorem ipsum dolor sit amet consectetur adipiscing elit. Consectetur aut ea reprehenderit unde quisquam doloremque ducimus assumenda magnam praesentium, similique asperiores corrupti maiores, quis minima molestias eum id cum iusto."
  />
      <Article title="Artikle 3" text="Lorem ipsum dolor sit amet consectetur adipiscing elit. Consectetur aut ea reprehenderit unde quisquam doloremque ducimus assumenda magnam praesentium, similique asperiores corrupti maiores, quis minima molestias eum id cum iusto."
  />
    </div>
  );
}

export default App;
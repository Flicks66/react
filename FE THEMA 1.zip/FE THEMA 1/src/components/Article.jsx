
function Article(props) {
    return (
        <>
            <h2>{props.title}</h2>
            <p>{props.author}</p>
            <p>{props.text}</p>
        </>
    )
}

export default Article;
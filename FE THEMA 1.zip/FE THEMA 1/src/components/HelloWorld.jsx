// src/components/HelloWorld.jsx
function HelloWorld(props) {
  return (
    <div>
      <h2>Hallo daar!</h2>
      <p>Ik ben {props.name} en ik ben {props.age} jaar oud.</p>
      <p>Mijn hobby is {props.hobby}.</p>
    </div>
  );
}

export default HelloWorld;